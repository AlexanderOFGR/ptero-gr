<?php
/**
 * Pterodactyl - Panel
 * Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com>.
 *
 * This software is licensed under the terms of the MIT license.
 * https://opensource.org/licenses/MIT
 */

return [
    'notices' => [
        'created' => 'Ένα νέο Nest, :name, δημιουργήθηκε με επιτυχία.',
        'deleted' => 'Εγινε επιτυχής διαγραφή του nest απο το Panel.',
        'updated' => 'Ανανεώθηκαν οι ρυθμίσεις του Nest με επιτυχία.',
    ],
    'eggs' => [
        'notices' => [
            'imported' => 'Η εισαγωγή αυτού του Egg και των σχετικών μεταβλητών ολοκληρώθηκε με επιτυχία.',
            'updated_via_import' => 'Αυτό το Egg έχει ενημερωθεί χρησιμοποιώντας το παρεχόμενο αρχείο.',
            'deleted' => 'Διαγράφηκε με επιτυχία το ζητούμενο Egg από το Panel.',
            'updated' => 'Η διαμόρφωση του Egg ενημερώθηκε με επιτυχία.',
            'script_updated' => 'Το σενάριο εγκατάστασης του Egg έχει ενημερωθεί και θα εκτελείται κάθε φορά που θα εγκαθίστανται servers.',
            'egg_created' => 'Ένα νέο αυγό δημιουργήθηκε με επιτυχία. Θα χρειαστεί να επανεκκινήσετε όλα Daemons που τρέχουν για να εφαρμόσετε αυτό το Egg.',
        ],
    ],
    'variables' => [
        'notices' => [
            'variable_deleted' => 'Η μεταβλητή ":variable" έχει διαγραφεί και δεν θα είναι πλέον διαθέσιμη στους servers μόλις ανακατασκευαστούν.',
            'variable_updated' => 'Η μεταβλητή ":variable" ενημερώθηκε. Μπορεί να χρειαστεί να ανακατασκευάσεις όσους servers την χρησιμοποιούν.',
            'variable_created' => 'Νέα μεταβλητή δημιουργήθηκε με επιτυχία και αντιστοιχίστηκε σε αυτό το Egg.',
        ],
    ],
];
