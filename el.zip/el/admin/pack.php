<?php
/**
 * Pterodactyl - Panel
 * Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com>.
 *
 * This software is licensed under the terms of the MIT license.
 * https://opensource.org/licenses/MIT
 */

return [
    'notices' => [
        'pack_updated' => 'Το πακέτο ενημερώθηκε με επιτυχία.',
        'pack_deleted' => 'Διαγράφηκε με επιτυχία το πακέτο ":name" απο το σύστημα.',
        'pack_created' => 'Ένα νέο πακέτο δημιουργήθηκε με επιτυχία και είναι έτοιμο για χρήση στους servers.',
    ],
];
