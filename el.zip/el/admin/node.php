<?php
/**
 * Pterodactyl - Panel
 * Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com>.
 *
 * This software is licensed under the terms of the MIT license.
 * https://opensource.org/licenses/MIT
 */

return [
    'validation' => [
        'fqdn_not_resolvable' => 'To Domain ή η διεύθυνση IP που παρέχεται δεν επιλύει μια έγκυρη διεύθυνση IP.',
        'fqdn_required_for_ssl' => 'Απαιτείται ένα Πλήρως Αναγνωρισμένο Domain Name που καταλήγει σε μια δημόσια διεύθυνση IP για τη χρήση SSL σε αυτό το node.',
    ],
    'notices' => [
        'allocations_added' => 'Οι κατανομές προστέθηκαν με επιτυχία σε αυτό το node.',
        'node_deleted' => 'Το Node αφαιρέθηκε με επιτυχία απο το Panel',
        'location_required' => 'Πρέπει να υπάρχει τουλάχιστον μια τοποθεσία για να προστεθεί το Node στο Panel',
        'node_created' => 'Ένα νέο node δημιουργήθηκε με επιτυχία. Μπορείς να το ρυθμίσεις αυτόματα στην σελίδα\'Ρυθμίσεις\'. <strong>Πρίν δημιουργήσεις κάπιον server, πρέπει να προσθέσιες τουλάχιστον μια θύρα και μία διεύθυνση IP.</strong>',
        'node_updated' => 'Οι πληροφορίες του Node ενημερώθηκαν με επιτυχία. Εάν άλλαξες κάποια ρύθμιση, θα πρέπει να το επανεκκινήσεις για να λάβουν μέρος.',
        'unallocated_deleted' => 'Διαγράφηκαν όλες οι μη εκχωρημένες θύρες για την <code>:ip</code>.',
    ],
];