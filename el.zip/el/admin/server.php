<?php
/**
 * Pterodactyl - Panel
 * Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com>.
 *
 * This software is licensed under the terms of the MIT license.
 * https://opensource.org/licenses/MIT
 */

return [
    'exceptions' => [
        'no_new_default_allocation' => 'Προσπαθείς να διαγράψεις την κύρια κατανομή χωρίς να υπάρχει άλλη για να χρησιμοποιηθεί.',
        'marked_as_failed' => 'Αυτός ο server χαρακτηρίστηκε ως αποτυχημένος σε προηγούμενη εγκατάσταση. Δεν είναι δυνατή η εναλλαγή της τρέχουσας κατάστασης πλέον.',
        'bad_variable' => 'Υπήρξε ένα πρόβλημα κατά την επικύρωση της μεταβλητής :name .',
        'daemon_exception' => 'Υπήρξε μια εξαίρεση κατά την προσπάθεια επικοινωνίας με το Daemon με αποτέλεσμα τον κωδικό απόκρισης HTTP/:code. Αυτή η εξαίρεση καταγράφηκε.',
        'default_allocation_not_found' => 'Η ζητούμενη προεπιλεγμένη κατανομή δεν βρέθηκε στις εκχωρήσεις αυτού του server.',
    ],
    'alerts' => [
        'startup_changed' => 'Οι ρυθμίσεις εκκίνησης αυτόυ του server ενημερώθηκαν. Εάν έγινε αλλαγή του Egg ή του Nest μια επανεγκατάσταση θα πραγματοποιηθεί αμέσως.',
        'server_deleted' => 'Ο Server διαγράφηκε με απιτυχία απο το σύστημα.',
        'server_created' => 'Ο Server δημιουργήθηκε με επιτυχία στο Panel. Παρακαλώ επιτρέψτε μερικά λεπτά στο Daemon ώστε να πραγματοποιηθεί η εγκατάσταση.',
        'build_updated' => 'Τα build details του server ανανεώθηκαν. Θα χρειαστεί να τον επανεκκινήσετε ωστε να λάβουν μέρος.',
        'suspension_toggled' => 'Η κατάσταση αναστολής server έχει αλλάξει σε :status.',
        'rebuild_on_boot' => 'Θα πραγματοποιηθεί rebuild του Docker Container αυτού του server στην επόμενη εκκίνηση.',
        'install_toggled' => 'Η κατάσταση εγκατάστασης για αυτόν τον server έχει αλλάξει.',
        'server_reinstalled' => 'Ο Server έχει μπεί σε ουρά για επανεγκατάσταση.',
        'details_updated' => 'Οι πληροφορίες του server ενημερώθηκαν',
        'docker_image_updated' => 'Άλλαξε με επιτυχία η κύρια εικόνα Docker για χρήση σε αυτόν τον server. Θα χρειαστεί επανεκκίνηση για να λάβουν μέρος οι αλλαγές',
        'node_required' => 'Χρειάζεται να υπάρχει τουλάχιστον ένα Node στο σύστημα πρίν μπορέσεις να δημιουργήσεις έναν server',
    ],
];
