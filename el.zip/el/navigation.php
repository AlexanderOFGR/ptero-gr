<?php

return [
    'home' => 'Home',
    'account' => [
        'header' => 'ΔΕΙΑΧΕΙΡΗΣΗ ΛΟΓΑΡΙΑΣΜΟΥ',
        'my_account' => 'Ο λογαριασμός μου',
        'security_controls' => 'Ασφάλεια Λογαριασμού',
        'api_access' => 'API Λογαριασμού',
        'my_servers' => 'Οι servers μου',
    ],
    'server' => [
        'header' => 'ΔΙΑΧΕΙΡΙΣΗ SERVER',
        'console' => 'Κονσόλα',
        'console-pop' => 'Κοσνόλα πλήρους οθόνης',
        'file_management' => 'Διαχείριση Αρχείων',
        'file_browser' => 'Διαχειριστής Αρχείων',
        'create_file' => 'Δημιουργία Αρχείου',
        'upload_files' => 'Ανέβασμα Αρχείου',
        'subusers' => 'Άλλοι Χρήστες',
        'schedules' => 'Σχέδια',
        'configuration' => 'Ρυθμίσεις',
        'port_allocations' => 'Ρυθμίσεις κατανομών',
        'sftp_settings' => 'Ρυθμίσεις SFTP',
        'startup_parameters' => 'Παράμετροι εκκίνησης',
        'databases' => 'Βάσεις Δεδομένων',
        'edit_file' => 'Επεξεργασία Αρχείου',
        'admin_header' => 'ΓΙΑ ΔΙΑΧΕΙΡΙΣΤΕΣ',
        'admin' => 'Server Configuration',
        'server_name' => 'Ονομασία Server',
    ],
];
